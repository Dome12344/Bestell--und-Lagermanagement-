﻿using System;
using System.Collections.Generic;

namespace Bestell__und_Lagermanagement.model
{
    public partial class Verzeichnis
    {
        public int VerzeichnisId { get; set; }
        public int Verwaltungsnummrer { get; set; }
        public string? Lagerort { get; set; }
    }
}
