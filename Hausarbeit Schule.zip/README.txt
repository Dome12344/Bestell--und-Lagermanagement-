Readme. Bestell- und Lagermanagement
Hier mit stelle ich ihnen meine Hausarbeit eine Bestell- und Lagermanagement vor.
1.  Zu erst muss die beigefüget SQL Datenbank ins eigene System der SQL hinzugefügt werden.
2.  Um sich ins System ein zu loggen benutzen sie:
2.1 Benutzername Markus, Passwort hausberger1, Mitarbeiternummer 500 als Admin
2.2 Benutzername Lukas, Passwort landshaus1, Mitarbeiternummer 501 als Lagerarbeiter 
2.3 Benutzername Tim, Passwort bergbach1, Mitarbeiternummer 100501 als Logistikmitarbeiter für Bestellung und Lieferantenverwaltung    
3.  Bei den ersten Profil mit dem Admin haben sie eine Mitarbeiter Ansicht in den sie alle Mitarbeiter des Betriebs sehen und die Möglichkeit haben,
    dass Passwort von jeden zu ändern. Bei einer Passwort  Änderung müssen sie die zu anderen Zeile anklicken und die Zeile wo davor neues Passwort
    steht ein neues Passwort eingeben und mit dem Button neues Passwort generieren erstellt er neues Passwort. Dann muss man auf die Zeile bei
    der angezeigten Tabelle um das neues Passwort zu speichern mit dem Button Passwort speichern.
4.  Mit dem Button Profil anlegen kann man ein Mitarbeiter im System hinzufügen mit der Bedingung, dass Mitarbeiter mit denn Nummern 0 bis 500 Admins sind,
    von 501 bis 100500 sind Logistikmitarbeiter für Bestellung und Lieferantenverwaltung und ab 100501 sind Lagerarbeiter.
5.  Mit Passwort ändern kann man mit der Mitarbeiternummer das Passwort des Mitarbeiters ändern.
6.  Lieferanten Verwaltung wird mit 3 Ausführbaren Möglichkeiten:
6.1 Lieferanten Ansicht: Dies zeigt alle Daten der Vorhanden Daten der Lieferanten an und ermöglicht die Suche mit den Lieferantennummer, Lieferanten Namen und welche
    Ware sind verfügbar.
6.2 Lieferanten bearbeiten ermöglicht Änderungen an den Angaben der Datenbank Inhalt bei Lieferanten und man muss beachten bei Preis hier ein "." für Cent betrage zu setzen
6.3 Lieferanten hinzufügen ermöglicht neue Lieferanten hinzufügen und man muss beachten bei Preis hier ein "," für Cent betrage zu setzen.        
7.  Bestellung Verwaltung wird mit 3 Ausführbaren Möglichkeiten:
7.1 Bestellung Ansicht: Dies zeigt alle Daten der Vorhanden Daten der Bestellung an und ermöglicht die Suche mit den Bestellnummer, Lieferantennummer und 
    Lagerort
7.2 Bestellung bearbeiten ermöglicht Änderungen an den Angaben der Datenbank Inhalt bei Bestellung und man muss bei Datum die deutsch Schreibweise vom Datum
    angeben z.B. "01.01.2025". 
7.3 Bestellung Aufgeben und Stornieren ermöglicht neue Bestellung hinzufügen oder diese zu Stornieren:
    -Bei Bestellung Aufgeben man muss beachten die Englische Datum Angabe zu machen Jahr, Monta, Tag um sie hinzu zufügen.
    -Bei Bestellung Stornieren muss nur die Bestellnummer angeben um die Bestellung zu Stornieren und aus der Datenbank zu löschen.
8.  Lager Verwaltung wird mit 3 Ausführbaren Möglichkeiten:
8.1 Lagerinhalt Ansicht: Dies zeigt alle Daten der Vorhanden Daten der Lagerinhalt an und ermöglicht die Suche mit den Lagernummer, Material/Waren Bezeichnung und Lagerort.
8.2 Lagerinhalt bearbeiten ermöglicht Änderungen an den Angaben der Datenbank Inhalt bei Lagerinhalt und man muss beachten bei den Längen die angaben ob es "mm,cm,dm oder m" es sich handelt.
    Des Weiteren wird dort die Warenannahme vermerkt und wenn Ware/Material hinzugefügt werden von mit dem gleichen Namen muss man den Altenwert mit dem neu hinzu kommen Wert selber erst zusammen rechen, gleiches bei #
    Warenentnahme im Lager.    
8.3 Lagerinhalt hinzufügen ermöglicht neue Lagerinhalt hinzufügen und man muss beachten bei den Längen die angaben ob es "mm,cm,dm oder m" es sich handelt.